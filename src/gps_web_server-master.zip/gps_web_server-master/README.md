# gps_web_server

gps web server 

请将map.html 和 js 文件放到终端的web 容器下。

比如树莓派可以使用boa ，将js  和html 放到 usr/local/share/boa 下

浏览器输入ip树莓派的ip地址即可。

https://github.com/horo2016/GPS_MAP_WEB/blob/master/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20200326140144_%E7%BC%96%E8%BE%91_%E7%BC%96%E8%BE%91.jpg
