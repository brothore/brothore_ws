# gps-map-server

1 git clone gps-map-server

2 cd gps-map-server

3 mkdir build 

4 make 

./demo


注意事项：

1 本程序使用json字符串发送信息。

2 运行此程序之前请确认安装mqtt server。确保

mosuitto_pub 

mosquitto_sub 能够实用并且支持web soc。

3 确保gps模块已经插上，并且存在 /dev/ttyUSB0 符合nmea协议，具有GPRMC字符串。

技术支持：839602830

支持网站：机器人车技术开发分享网（技发网）http://cvosrobot.com
http://blog.cvosrobot.com
